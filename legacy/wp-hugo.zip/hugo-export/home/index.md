---
title: Home
author: daniel
type: page
date: 2009-10-01T21:22:07+00:00

---
This site gathers demonstrations of various ways we can display
  
and share collected Electrical Consumption Data.

<div style="position:relative; margin-left:00px; margin-top:40px">
  This is a simple badge suitable for a portal site, such as <a href="http://www.google.com/ig" target="_blank">iGoogle</a>.</p> 
  
  <p>
    <iframe src ="http://imetrical.appspot.com/s/p/www-3b.html" width="350"  height="120" frameborder="0" scrolling="no" allowTransparency="true"></p> 
    
    <p>
      Your browser does not support iframes.
    </p>
    
    <p>
      </iframe> </div> 
      
      <div style="position:relative; margin-left:500px; margin-top:-240px; width:300px;">
        This is another more visual, but still concise display:</p> 
        
        <p>
          <iframe src ="http://imetrical.appspot.com/s/i/www-mw-chart.html" width="330"  height="220" frameborder="0" scrolling="no" allowTransparency="true"></p> 
          
          <p>
            Your browser does not support iframes.
          </p>
          
          <p>
            </iframe> </div>