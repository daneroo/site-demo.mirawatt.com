---
title: iPhone – Animated
author: daniel
type: post
date: 2009-10-06T02:25:07+00:00
url: /?p=121
categories:
  - iPhone (Webkit)

---
This is how the application looks on the iPhone.

Hover inside grey box to rotate _(only on Chrome)_

<div id="outeroffset" >
  <div id="outertransform">
    <div id="wrapperbg" >
      <div id="inneroffset" >
        <div id="overflowwrapper" >
          <div id="frametransform" >
            <iframe src ="http://imetrical.appspot.com/s/i/iphone-cache.html" width="320px"  height="560px" frameborder="0" scrolling="no" allowTransparency="true"></p> 
            
            <p>
              Your browser does not support iframes.
            </p>
            
            <p>
              </iframe> </div> </div> </div> </div> </div> </div>