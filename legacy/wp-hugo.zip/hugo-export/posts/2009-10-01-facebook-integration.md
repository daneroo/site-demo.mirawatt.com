---
title: Facebook Integration
author: daniel
type: post
date: 2009-10-01T23:11:43+00:00
url: /?p=17
categories:
  - Social

---
Integration with social media sites open up a wealth of possibilities.

We have created a simple <a href="http://apps.facebook.com/imetrical/" target="_blank">Facebook</a> application to show this.

We have also integrated with <a href="http://imetrical.ning.com/profiles/profile/apps?screenName=1jmxk0qpwpfnk" target="_blank">Ning</a> a social network in which you can build your own community.

<div style="width:700px; background-color:#ffffff;">
  <iframe style="position:relative; left:50px" src="http://imetrical.appspot.com/s/p/www-6bc.html" width="800px" height="533px" frameborder="0" scrolling="no" allowTransparency="true"></p> 
  
  <p>
    Your browser does not support iframes.
  </p>
  
  <p>
    </iframe> </div>