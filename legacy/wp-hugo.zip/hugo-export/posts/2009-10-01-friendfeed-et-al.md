---
title: FriendFeed et al.
author: daniel
type: post
date: 2009-10-02T01:16:12+00:00
url: /?p=27
categories:
  - MicroBlog

---
Microblogging services such as Twitter and FriendFeed,
  
can be used to share selected stream of information, selectively.

Here we see a rolling 24 hour snapshot of consumption, broadcast every few hours

<a title="FriendFeed" href="http://friendfeed.com/imetrical" target="_blank">Open Friendfeed in new window</a> &#8211; or- just <a title="FriendFeed Search" href="http://friendfeed.com/search?q=power+consumption+from%3Aimetrical" target="_blank">(Search)</a>

<div style="width:700px; height:833px; overflow:hidden; padding-left:-100px;">
  <iframe style="position:relative; top:-140px" src="http://friendfeed.com/search?q=power+consumption+from%3Aimetrical" width="800px" height="833px" frameborder="0" scrolling="no" allowTransparency="true"></p> 
  
  <p>
    Your browser does not support iframes.
  </p>
  
  <p>
    </iframe> </div>