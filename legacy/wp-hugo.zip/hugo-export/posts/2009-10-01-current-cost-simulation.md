---
title: Current Cost Simulation
author: daniel
type: post
date: 2009-10-01T22:06:10+00:00
url: /?p=9
categories:
  - Current Cost

---
Here is the simulator:
  
http://imetrical.appspot.com/s/cc128/cc128sim.html

<div style="width:700px; height:533px; overflow:hidden; padding-left:000px;">
  <iframe style="position:relative; left:-0px" src="http://imetrical.appspot.com/s/cc128/cc128sim.html" width="700px" height="533px" frameborder="0" scrolling="no" allowTransparency="true"></p> 
  
  <p>
    Your browser does not support iframes.
  </p>
  
  <p>
    </iframe> </div>