---
title: iPhone Aplication (Web)
author: daniel
type: post
date: 2009-10-06T01:29:23+00:00
url: /?p=70
categories:
  - iPhone

---
This is how the application looks on the iPhone. 

<div style="padding-left:180px;">
  <div style="width:408px; height:740px; background-image:url('http://imetrical.appspot.com/s/i/mirawattIPhone-bg-for-320x460.png'); background-repeat:none; background-position:0 0; padding:0px; margin:0px; ">
    <div style="padding-left:45px;padding-top:157px;">
      <div style="width:320px; height:460px; overflow:hidden;">
        <!-- height to accomodate info section on chrome... scroll=no has no effect -->
        
        <br /> <iframe src ="http://imetrical.appspot.com/s/i/iphone-cache.html" width="320px"  height="560px" frameborder="0" scrolling="no" allowTransparency="true"></p> 
        
        <p>
          Your browser does not support iframes.
        </p>
        
        <p>
          </iframe> </div> </div> </div> </div>