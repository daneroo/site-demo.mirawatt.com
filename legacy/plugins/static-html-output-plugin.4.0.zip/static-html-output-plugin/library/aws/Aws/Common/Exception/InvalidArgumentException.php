<?php
namespace Aws\Common\Exception;
class InvalidArgumentException extends \InvalidArgumentException implements AwsExceptionInterface {}
