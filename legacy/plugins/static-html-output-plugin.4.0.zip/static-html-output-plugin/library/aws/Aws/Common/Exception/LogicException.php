<?php
namespace Aws\Common\Exception;
class LogicException extends \LogicException implements AwsExceptionInterface {}
