<?php
namespace Aws\Common\Exception;
class UnexpectedValueException extends \UnexpectedValueException implements AwsExceptionInterface {}
