<?php
namespace Aws\Common\Exception;
class OutOfBoundsException extends \OutOfBoundsException implements AwsExceptionInterface {}
