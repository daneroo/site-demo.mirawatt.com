<?php
namespace Aws\Common\Exception;
class BadMethodCallException extends \BadMethodCallException implements AwsExceptionInterface {}
