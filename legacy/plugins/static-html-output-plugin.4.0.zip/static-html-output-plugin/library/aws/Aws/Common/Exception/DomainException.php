<?php
namespace Aws\Common\Exception;
class DomainException extends \DomainException implements AwsExceptionInterface {}
