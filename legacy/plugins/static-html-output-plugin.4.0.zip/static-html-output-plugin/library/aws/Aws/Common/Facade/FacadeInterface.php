<?php
namespace Aws\Common\Facade;
interface FacadeInterface
{
    public static function getServiceBuilderKey();
}
