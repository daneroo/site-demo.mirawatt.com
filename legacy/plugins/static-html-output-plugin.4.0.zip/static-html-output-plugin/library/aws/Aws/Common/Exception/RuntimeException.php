<?php
namespace Aws\Common\Exception;
class RuntimeException extends \RuntimeException implements AwsExceptionInterface {}
